package com.dependency.injection;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InjectionApplicationTests {

	@Test
	void contextLoads() {
	}

}

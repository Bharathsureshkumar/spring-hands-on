package com.bean.scopes;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ScopesApplication {

	public static void main(String[] args) {
		SpringApplication.run(ScopesApplication.class, args);
	}

}

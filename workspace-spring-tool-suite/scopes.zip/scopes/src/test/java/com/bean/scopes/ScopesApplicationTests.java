package com.bean.scopes;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ScopesApplicationTests {

	@Test
	void contextLoads() {
	}

}

package com.bean.postprocessor;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PostprocessorApplicationTests {

	@Test
	void contextLoads() {
	}

}

package com.bean.lifecycle;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LifecycleApplicationTests {

	@Test
	void contextLoads() {
	}

}
